package br.com.barbeariachicoleme;

import android.os.StrictMode;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexao {

    public static Connection conectar(){

        String connSomee = "jdbc:jtds:sqlserver://ChicoBD.mssql.somee.com;databaseName=ChicoBD;user=Pyisaac17_SQLLogin_1;password=xyl3m6ie5h";
        //Objeto de conexão
        Connection conn;
        try {
            //Adicionar poliitica para criação de thead
            StrictMode.ThreadPolicy policy;
            policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);

            //Valida se o driver esta adicionado no projeto
            Class.forName("net.sourceforge.jtds.jdbc.Driver");

            //Configura conexao
            conn = DriverManager.getConnection(connSomee);

            return conn;

        } catch (ClassNotFoundException | SQLException e) {
            throw new RuntimeException(e);
        }

    }

}
