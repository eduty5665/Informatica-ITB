package br.com.barbeariachicoleme.Model;

public class Usuario {

    private String id;
    private String username;
    private String user_password;
    private String email;
    private String cell;
    private int quants_corte;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getUser_password() {
        return user_password;
    }

    public void setUser_password(String user_password) {
        this.user_password = user_password;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getCell() {
        return cell;
    }

    public void setCell(String cell) {
        this.cell = cell;
    }

    public int getQuants_corte() {
        return quants_corte;
    }

    public void setQuants_corte(int quants_corte) {
        this.quants_corte = quants_corte;
    }
}
