package br.com.barbeariachicoleme;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.appcompat.widget.AppCompatEditText;
import androidx.appcompat.widget.AppCompatTextView;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.PatternMatcher;
import android.os.StrictMode;
import android.util.Patterns;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.santalu.maskara.widget.MaskEditText;

import br.com.barbeariachicoleme.DAO.UsuarioDAO;

public class CadastroActivity extends AppCompatActivity {

    protected AppCompatEditText mEditTextUsername, mEditTextEmail, mEditTextSenha;
    protected MaskEditText mMaskEditTextTelefone;
    protected AppCompatButton mButtonCadastrar;
    protected AppCompatTextView mTextViewGoToLogin;
    protected ProgressBar mProgressBarCad;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro);

        mEditTextUsername = findViewById(R.id.editText_nome_cad);
        mEditTextEmail = findViewById(R.id.editText_email_cad);
        mMaskEditTextTelefone = findViewById(R.id.editText_numero_cad);
        mEditTextSenha = findViewById(R.id.editText_password_cad);
        mButtonCadastrar = findViewById(R.id.button_cad);
        mTextViewGoToLogin = findViewById(R.id.goToLogin);
        mProgressBarCad = findViewById(R.id.progressbar_cad);

        mTextViewGoToLogin.setOnClickListener(v -> startActivity(new Intent(this, LoginActivity.class)));

        mButtonCadastrar.setOnClickListener(v -> {
            mProgressBarCad.setVisibility(View.VISIBLE);

            new Handler().postDelayed(() ->
                cadastrar(mEditTextUsername.getText().toString()
                , mEditTextEmail.getText().toString()
                , mMaskEditTextTelefone.getText().toString()
                , mEditTextSenha.getText().toString()),500);
        });

    }

    private boolean validarDados(String username, String email, String telefone, String senha) {

        boolean res = false;

        if (username.isEmpty() || email.isEmpty() || telefone.isEmpty() || senha.isEmpty()) {
            Toast.makeText(this, "Preencha todos os dados", Toast.LENGTH_SHORT).show();
        } else if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            Toast.makeText(this, "Digite um email valido", Toast.LENGTH_SHORT).show();
        } else if (telefone.length() < 14) {
            Toast.makeText(this, "Digite um telefone valido", Toast.LENGTH_SHORT).show();
        } else if (senha.length() < 6) {
            Toast.makeText(this, "A senha deve conter no minimo 6 caracteres", Toast.LENGTH_SHORT).show();
        } else if (UsuarioDAO.validarUsername(username) != 0) {
            Toast.makeText(this, "Este username já está em uso", Toast.LENGTH_SHORT).show();
        } else if (UsuarioDAO.validarTelefone(telefone) != 0) {
            Toast.makeText(this, "Este telefone já está em uso", Toast.LENGTH_SHORT).show();
        } else {
            res = true;
        }
        return res;
    }

    private void cadastrar(String username, String email, String telefone, String senha) {

        if (validarDados(username, email, telefone, senha)) {
            int res = UsuarioDAO.cadastrarUsuario(username, email, telefone, senha);

            if (res != 0) {
                startActivity(new Intent(this, LoginActivity.class));
                Toast.makeText(this, "Usuario cadastrado com sucesso", Toast.LENGTH_SHORT).show();
                finish();
            } else {
                Toast.makeText(this, "erro", Toast.LENGTH_SHORT).show();
            }

        } else {
            mProgressBarCad.setVisibility(View.INVISIBLE);
        }

    }
}
