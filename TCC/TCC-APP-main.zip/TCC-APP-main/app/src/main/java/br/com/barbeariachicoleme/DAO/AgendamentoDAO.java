package br.com.barbeariachicoleme.DAO;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.com.barbeariachicoleme.Conexao;
import br.com.barbeariachicoleme.Model.Agendamento;

public class AgendamentoDAO {

    private static final String SQL_GET_AGENDAMENTO = "SELECT * FROM agendamento WHERE id_cliente = ?";
    private static final  String SQL_DELETE_AGENDAMENTO = "DELETE FROM agendamento WHERE id = ?";

    public static List<Agendamento> listaAgendamento(String id) {
        List<Agendamento> list = new ArrayList<>();
        PreparedStatement pst;
        ResultSet rs;

        try {
            pst = Conexao.conectar().prepareStatement(SQL_GET_AGENDAMENTO);
            pst.setString(1, id);

            rs = pst.executeQuery();

            while (rs.next()) {
                Agendamento agendamento = new Agendamento();
                agendamento.setId(rs.getString(1));
                agendamento.setId_client(rs.getString(2));
                agendamento.setData(rs.getString(3));
                agendamento.setHorario(rs.getString(4));
                agendamento.setTipo_corte(rs.getString(5));

                list.add(agendamento);
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        return list;
    }

    public static int deletarAgendamento(String id){
        int res = 0;
        int linhasAfetadas;
        PreparedStatement pst;


        try {
            pst = Conexao.conectar().prepareStatement(SQL_DELETE_AGENDAMENTO);
            pst.setString(1, id);

            linhasAfetadas = pst.executeUpdate();

            if(linhasAfetadas > 0){
                res = 1;
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }


        return res;
    }

}
