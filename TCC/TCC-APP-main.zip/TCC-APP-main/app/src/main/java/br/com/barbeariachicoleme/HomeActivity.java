package br.com.barbeariachicoleme;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;

import br.com.barbeariachicoleme.Adapter.Adapter;
import br.com.barbeariachicoleme.DAO.AgendamentoDAO;
import br.com.barbeariachicoleme.DAO.UsuarioDAO;

import br.com.barbeariachicoleme.Model.Usuario;

public class HomeActivity extends AppCompatActivity {

    private AppCompatTextView mTextViewNomeWellcome, mTextViewCorteGrats;
    private ImageView mImageViewLogOut, mImageViewPerfil;
    private ProgressBar mProgressBarHome;
    private RecyclerView mRecyclerViewHome;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        String id = getIntent().getExtras().getString("id");
        Usuario usuario = UsuarioDAO.getUsuario(id);
        int quantCortes = usuario.getQuants_corte() / 10;
        String cortesGratis = quantCortes + " cortes grátis";
        String nomeUsu = usuario.getUsername();

        mTextViewNomeWellcome = findViewById(R.id.nome_home);
        mTextViewCorteGrats = findViewById(R.id.cortes_gratis_home);
        mImageViewLogOut = findViewById(R.id.logout_home);
        mImageViewPerfil = findViewById(R.id.perfil_home);
        mProgressBarHome = findViewById(R.id.progressBar_Home);

        mImageViewPerfil.setOnClickListener(v -> {
            mProgressBarHome.setVisibility(View.VISIBLE);
            Intent intent = new Intent(this, PerfilActivity.class);
            intent.putExtra("id", id);
            startActivity(intent);
            finish();
        });

        mImageViewLogOut.setOnClickListener(v ->{
            mProgressBarHome.setVisibility(View.VISIBLE);
            finishAffinity();} );

        mTextViewNomeWellcome.setText(nomeUsu);
        mTextViewCorteGrats.setText(cortesGratis);
        configRecyclerView(id);
    }

    private void configRecyclerView(String id){

        mRecyclerViewHome = findViewById(R.id.recyclerView_MeusAgendamentos);
        Adapter adapter = new Adapter(AgendamentoDAO.listaAgendamento(id), this);
        mRecyclerViewHome.setLayoutManager(new LinearLayoutManager(this));
        mRecyclerViewHome.setAdapter(adapter);

    }

}