package br.com.barbeariachicoleme;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.LinearLayoutCompat;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.santalu.maskara.widget.MaskEditText;

import br.com.barbeariachicoleme.DAO.UsuarioDAO;
import br.com.barbeariachicoleme.Model.Usuario;

public class PerfilActivity extends AppCompatActivity {

    private EditText mEditTextUsername, mEditTextEmail,  mEditTextSenha, mEditTextTelefone;
    private Button mButtonSave, mButtonSair;
    private TextView mTextViewNome;
    private ProgressBar mProgressBarPerfil;
    private ImageView mImageViewGoback, mImageViewEdit, mImageViewDelete;
    private LinearLayoutCompat mLinearLayoutCompatEdit;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_perfil);
        //pega o id do usuario logado
        String id = getIntent().getExtras().getString("id");

        mEditTextUsername = findViewById(R.id.editUsername_perfil);
        mEditTextEmail = findViewById(R.id.edit_email_perfil);
        mEditTextTelefone = findViewById(R.id.edit_telefone_perfil);
        mEditTextSenha = findViewById(R.id.edit_senha_perfil);
        mTextViewNome = findViewById(R.id.nome_perfil);
        mImageViewGoback = findViewById(R.id.goBack_perfil);
        mButtonSair = findViewById(R.id.sair_perfil);
        mButtonSave = findViewById(R.id.save_perfil);
        mImageViewEdit = findViewById(R.id.editar_perfil);
        mImageViewDelete = findViewById(R.id.delete_perfil);
        mLinearLayoutCompatEdit = findViewById(R.id.layout_edit_perfil);
        mProgressBarPerfil = findViewById(R.id.progressBar_Perfil);

        setInfo(id);

        mButtonSair.setOnClickListener(v -> logOut());

        mButtonSave.setOnClickListener(v -> update(id, mEditTextUsername.getText().toString()
                , mEditTextEmail.getText().toString()
                , mEditTextTelefone.getText().toString(),
                mEditTextSenha.getText().toString()));

        mImageViewEdit.setOnClickListener(v -> editar());

        mImageViewGoback.setOnClickListener(v -> {
            mProgressBarPerfil.setVisibility(View.VISIBLE);
            Intent intent = new Intent(this, HomeActivity.class);
            intent.putExtra("id", id);
            startActivity(intent);
            finish();
        });

        mImageViewDelete.setOnClickListener(v -> deletarUsuario(id));

    }

    private void setInfo(String id){
        //Pega os dados do usuario pelo id passado pela intent
        Usuario usuario = UsuarioDAO.getUsuario(id);

        //seta os dados com o SharedPreferences ,se nao tiver ele coloca como valor padrao o usuario pego
            mTextViewNome.setText(usuario.getUsername());
            mEditTextUsername.setText(usuario.getUsername());
            mEditTextEmail.setText(usuario.getEmail());
            mEditTextTelefone.setText(usuario.getCell());
            mEditTextSenha.setText(usuario.getUser_password());

    }

    private void editar(){
        //0 visible 4 invisible 8 gone
        int visible = mLinearLayoutCompatEdit.getVisibility();

        if(visible == 0){
            mLinearLayoutCompatEdit.setVisibility(View.GONE);
            mImageViewEdit.setImageResource(R.drawable.ic_edit);
        } else {
            mLinearLayoutCompatEdit.setVisibility(View.VISIBLE);
            mImageViewEdit.setImageResource(R.drawable.ic_edit_off);

        }

    }

    private void update(String id, String username, String email, String telefone, String senha){



        if (username.isEmpty() || email.isEmpty() || senha.isEmpty()) {
            Toast.makeText(this, "Preencha todos os dados", Toast.LENGTH_SHORT).show();
        } else if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            Toast.makeText(this, "Digite um email valido", Toast.LENGTH_SHORT).show();
        } else if (telefone.length() < 14) {
            Toast.makeText(this, "Digite um telefone valido", Toast.LENGTH_SHORT).show();
        } else if (senha.length() < 6) {
            Toast.makeText(this, "A senha deve conter no minimo 6 caracteres", Toast.LENGTH_SHORT).show();
        } else {
            int res = UsuarioDAO.updateUsuario(id, username, email, telefone, senha);

            if (res != 0){
                Toast.makeText(this, "Dados atualizados com sucesso", Toast.LENGTH_SHORT).show();
                setInfo(id);
            } else {
                Toast.makeText(this, "erro", Toast.LENGTH_SHORT).show();
            }
        }

    }

    private void logOut(){

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Deseja sair da conta?");

        builder.setPositiveButton("Sim", (dialog, id1) -> {
            mProgressBarPerfil.setVisibility(View.VISIBLE);
            SharedPreferences mPrefs = getSharedPreferences("manterLogado", MODE_PRIVATE);
            SharedPreferences.Editor editor = mPrefs.edit();
            editor.clear();
            editor.apply();
            startActivity(new Intent(this, LoginActivity.class));
            finish();
        });

        builder.setNegativeButton("Não", (dialog, id1) -> dialog.dismiss());

        // Crie e mostre o AlertDialog
        AlertDialog dialog = builder.create();
        dialog.show();

    }

    private void deletarUsuario(String id){

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Deseja deletar o seu usuario?");

        builder.setPositiveButton("Sim", (dialog, id1) -> {
            int delete = UsuarioDAO.deletarUsuario(id);
            if (delete != 0){
                SharedPreferences mPrefs = getSharedPreferences("manterLogado", MODE_PRIVATE);
                SharedPreferences.Editor editor = mPrefs.edit();
                editor.clear();
                editor.apply();
                startActivity(new Intent(this, LoginActivity.class));
                finish();
            } else {
                Toast.makeText(this, "erro", Toast.LENGTH_SHORT).show();
            }
        });

        builder.setNegativeButton("Não", (dialog, id1) -> {

            dialog.dismiss();
        });

        AlertDialog dialog = builder.create();
        dialog.show();

    }

}