package br.com.barbeariachicoleme.DAO;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import br.com.barbeariachicoleme.Conexao;
import br.com.barbeariachicoleme.Model.Usuario;

public class UsuarioDAO {

    private static final String SQL_LOGAR = "SELECT * FROM usuarios WHERE username = ? AND user_password = ?";
    private static final String SQL_GETUSER = "SELECT * FROM usuarios WHERE id =  ?";
    private static final String SQL_CADASTRAR = "INSERT INTO usuarios(username, email,cell, user_password, nivelacesso) VALUES (?, ?, ?, ?, '0')";
    private static final String SQL_VALIDADE_USERNAME = "SELECT * FROM usuarios WHERE username = ?";
    private static final String SQL_VALIDADE_EMAIL = "SELECT * FROM usuarios WHERE email = ?";
    private static final String SQL_VALIDADE_TELEFONE = "SELECT * FROM usuarios WHERE cell = ?";
    private static final String SQL_UPDATE = "UPDATE usuarios SET username = ?, email = ?,  cell = ?, user_password = ? WHERE id = ?";
    private static final String SQL_DELETE = "DELETE FROM usuarios WHERE id = ?";

    public static int logar(String username, String senha){
        int id = 0;
        PreparedStatement pst;

        try {
            pst = Conexao.conectar().prepareStatement(SQL_LOGAR);
            pst.setString(1, username);
            pst.setString(2, senha);

            ResultSet rs = pst.executeQuery();
            if(rs.next()){
                id = rs.getInt(1);
            }

        } catch (SQLException e){
            e.getMessage();
        }

        return id;
    }

    public static Usuario getUsuario(String id){
        Usuario usuario = new Usuario();
        PreparedStatement pst;
        ResultSet rs;

        try {
        pst = Conexao.conectar().prepareStatement(SQL_GETUSER);
        pst.setString(1, id);

        rs = pst.executeQuery();

        if (rs.next()){
            usuario.setUsername(rs.getString(2));
            usuario.setUser_password(rs.getString(3));
            usuario.setEmail(rs.getString(4));
            usuario.setCell(rs.getString(5));
            usuario.setQuants_corte(rs.getInt(7));
        }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        return usuario;

    }

    public static int cadastrarUsuario(String nome, String email, String telefone, String senha){
        int res = 0;
        int linhasafetadas;
        PreparedStatement pst;

        try {
            pst = Conexao.conectar().prepareStatement(SQL_CADASTRAR);

        pst.setString(1, nome);
        pst.setString(2, email);
        pst.setString(3, telefone);
        pst.setString(4, senha);

        linhasafetadas = pst.executeUpdate();

        if (linhasafetadas > 0){
            res = 1;
        }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return res;
    }

    public static int validarUsername(String username){
        int res = 0;
        PreparedStatement pst;
        ResultSet rs;

        try {
            pst = Conexao.conectar().prepareStatement(SQL_VALIDADE_USERNAME);
            pst.setString(1, username);

            rs = pst.executeQuery();

            if (rs.next()){
                res = 1;
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        return res;
    }

    public static int validarEmail(String email){
        int res = 0;
        PreparedStatement pst;
        ResultSet rs;

        try {
            pst = Conexao.conectar().prepareStatement(SQL_VALIDADE_EMAIL);
            pst.setString(1, email);

            rs = pst.executeQuery();

            if (rs.next()){
                res = 1;
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        return res;
    }

    public static int validarTelefone(String telefone){
        int res = 0;
        PreparedStatement pst;
        ResultSet rs;

        try {
            pst = Conexao.conectar().prepareStatement(SQL_VALIDADE_TELEFONE);
            pst.setString(1, telefone);

            rs = pst.executeQuery();

            if (rs.next()){
                res = 1;
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        return res;
    }

    public static int updateUsuario(String id, String username, String email, String telefone, String senha){
        int res = 0;
        int linhasAfetadas;
        PreparedStatement pst;

        try {
            pst = Conexao.conectar().prepareStatement(SQL_UPDATE);
            pst.setString(1, username);
            pst.setString(2, email);
            pst.setString(3, telefone);
            pst.setString(4, senha);
            pst.setString(5, id);

            linhasAfetadas = pst.executeUpdate();

            if(linhasAfetadas > 0){
                res = 1;
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        return res;
    }

    public static int deletarUsuario(String id){
        int res = 0;
        int linhasAfetadas;
        PreparedStatement pst;

        try {
            pst = Conexao.conectar().prepareStatement(SQL_DELETE);
            pst.setString(1, id);

            linhasAfetadas = pst.executeUpdate();

            if (linhasAfetadas > 0){
                res = 1;
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        return res;

    }

}
