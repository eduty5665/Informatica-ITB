package br.com.barbeariachicoleme.Model;

public class Agendamento {

    private String id;
    private String id_client;
    private String data;
    private String horario;
    private String tipo_corte;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getId_client() {
        return id_client;
    }

    public void setId_client(String id_client) {
        this.id_client = id_client;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public String getHorario() {
        return horario;
    }

    public void setHorario(String horario) {
        this.horario = horario;
    }

    public String getTipo_corte() {
        return tipo_corte;
    }

    public void setTipo_corte(String tipo_corte) {
        this.tipo_corte = tipo_corte;
    }
}
