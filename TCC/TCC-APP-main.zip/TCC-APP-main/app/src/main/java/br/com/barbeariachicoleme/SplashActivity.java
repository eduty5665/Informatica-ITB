package br.com.barbeariachicoleme;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;

public class SplashActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        String id;
        boolean logado;

        SharedPreferences mShaPrefs = getSharedPreferences("manterLogado", MODE_PRIVATE);
        id = mShaPrefs.getString("id", "");
        logado = mShaPrefs.getBoolean("logado", false);

        new Handler().postDelayed(() -> {
            if (logado) {
                Intent intent = new Intent(this, HomeActivity.class);
                intent.putExtra("id", id);
                startActivity(intent);
            } else {
                Intent intent = new Intent(this, LoginActivity.class);
                startActivity(intent);
            }
            finish();
        }, 2000);
    }
}