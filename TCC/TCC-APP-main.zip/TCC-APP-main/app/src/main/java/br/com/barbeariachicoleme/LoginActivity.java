package br.com.barbeariachicoleme;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.appcompat.widget.AppCompatEditText;
import androidx.appcompat.widget.AppCompatTextView;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.CheckBox;
import android.widget.ProgressBar;
import android.widget.Toast;

import java.util.Set;

import br.com.barbeariachicoleme.DAO.UsuarioDAO;
import br.com.barbeariachicoleme.Model.Usuario;

public class LoginActivity extends AppCompatActivity {

    private AppCompatEditText mEditTextUsername, mEditTextSenha;
    private AppCompatButton mButtonEntrar;
    private AppCompatTextView mTextViewGoToCad;
    public ProgressBar mProgressBarLogin;
    private CheckBox mCheckBoxManterLogado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        initComponentes();

        mTextViewGoToCad.setOnClickListener(v -> startActivity(new Intent(this, CadastroActivity.class)));

        mButtonEntrar.setOnClickListener(v -> {
            mProgressBarLogin.setVisibility(View.VISIBLE);
            new Handler().postDelayed(() -> entrar(mEditTextUsername.getText().toString(), mEditTextSenha.getText().toString()), 500);
           });
    }

    private void initComponentes(){
        mEditTextUsername = findViewById(R.id.editText_username_login);
        mEditTextSenha = findViewById(R.id.editText_password_login);
        mButtonEntrar = findViewById(R.id.button_login);
        mTextViewGoToCad = findViewById(R.id.goToCadastro);
        mProgressBarLogin = findViewById(R.id.progresbar_login);
        mCheckBoxManterLogado = findViewById(R.id.manterLogado_login);
    }

    private void manterLogado(String id){
        SharedPreferences mShaPrefs = getSharedPreferences("manterLogado", MODE_PRIVATE);
        SharedPreferences.Editor editor = mShaPrefs.edit();
        editor.putBoolean("logado", true);
        editor.putString("id", id);
        editor.apply();
    }

    private void entrar(String username, String senha){
        //obs res retorna o id do usuario que foi logado
        int res = UsuarioDAO.logar(username, senha);
        String id = String.valueOf(res);

        if (res != 0){

            if (mCheckBoxManterLogado.isChecked()){
                manterLogado(id);
                Intent intent = new Intent(this, HomeActivity.class);
                intent.putExtra("id", id);
                startActivity(intent);
                finish();
            }else {
                Intent intent = new Intent(this, HomeActivity.class);
                intent.putExtra("id", id);
                startActivity(intent);
                finish();
            }

        } else {
                Toast.makeText(this, "Usuario e/ou senha invalidos", Toast.LENGTH_SHORT).show();
                mProgressBarLogin.setVisibility(View.INVISIBLE);
        }

    }

}