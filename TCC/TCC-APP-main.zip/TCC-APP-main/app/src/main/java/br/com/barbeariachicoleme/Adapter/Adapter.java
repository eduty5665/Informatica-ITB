package br.com.barbeariachicoleme.Adapter;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;
import java.util.Set;

import br.com.barbeariachicoleme.DAO.AgendamentoDAO;
import br.com.barbeariachicoleme.DAO.UsuarioDAO;
import br.com.barbeariachicoleme.HomeActivity;
import br.com.barbeariachicoleme.LoginActivity;
import br.com.barbeariachicoleme.Model.Agendamento;
import br.com.barbeariachicoleme.R;

public class Adapter extends RecyclerView.Adapter<Adapter.ViewHolder> {

    private Context mContext;

    private final List<Agendamento> mValuesCorte;

    public Adapter(List<Agendamento> listaDeItens, Context context) {

        this.mContext = context;
        this.mValuesCorte = listaDeItens;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View itemLista = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_agendamentos, parent, false);
        return new ViewHolder(itemLista);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.mAgend = mValuesCorte.get(position);
        holder.hora.setText(mValuesCorte.get(position).getHorario());
        holder.data.setText(mValuesCorte.get(position).getData());
        holder.tipoCorte.setText(mValuesCorte.get(position).getTipo_corte());
        holder.delete.setOnClickListener(v -> deletarAgendamento(holder));
    }

    private void deletarAgendamento(ViewHolder holder) {
        LayoutInflater inflater = LayoutInflater.from(mContext);
        View meuLayout = inflater.inflate(R.layout.activity_home, null);

        AlertDialog.Builder builder = new AlertDialog.Builder(meuLayout.getContext());
        builder.setTitle("Deseja deletar seu agendamento?");
        builder.setPositiveButton("Sim", (dialog, id1) -> {
            int deletarAgendamento = AgendamentoDAO.deletarAgendamento(holder.mAgend.getId());

            if (deletarAgendamento > 0) {
                mValuesCorte.remove(holder.getAdapterPosition());
                notifyItemRemoved(holder.getAdapterPosition());
            }
        });

        builder.setNegativeButton("Não", (dialog, id1) -> dialog.dismiss());

        AlertDialog dialog = builder.create();
        dialog.show();

    }

    @Override
    public int getItemCount() {
        if (mValuesCorte != null) {
            return mValuesCorte.size();
        } else {
            return 0; // Lida com o caso em que a lista é nula
        }
    }

    public static class ViewHolder extends RecyclerView.ViewHolder{

        TextView data;
        TextView hora;
        TextView tipoCorte;
        ImageView delete;
        public Agendamento mAgend;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            data = itemView.findViewById(R.id.data_card);
            hora = itemView.findViewById(R.id.hora_card);
            tipoCorte = itemView.findViewById(R.id.tipocorte_card);
            delete = itemView.findViewById(R.id.delete_agendamento);
        }
    }

}
