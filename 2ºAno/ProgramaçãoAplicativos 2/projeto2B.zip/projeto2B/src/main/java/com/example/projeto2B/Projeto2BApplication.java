package com.example.projeto2B;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Projeto2BApplication {

	public static void main(String[] args) {
		SpringApplication.run(Projeto2BApplication.class, args);
	}

}
