package com.example.projeto2B;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Projeto2BApplicationTests {

	@Test
	void contextLoads() {
	}

}
